import{a}from"./chunk-IUUJRNCU.js";import"./chunk-VOQ37MMD.js";export{a as default};
//# sourceMappingURL=en-JOCWU7WT.js.map
