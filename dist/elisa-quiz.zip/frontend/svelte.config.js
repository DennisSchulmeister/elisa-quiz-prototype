export default {
	compilerOptions: {
		compatibility: {
			componentApi: 4
		}
	}
};